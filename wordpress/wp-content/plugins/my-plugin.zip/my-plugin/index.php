<?php
/* Silence is golden */
