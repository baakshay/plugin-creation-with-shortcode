<?php
/**
 * Plugin Name: My Plugin
 * Description: This is my test plugin.
 * Version: 1.0
 * Author: Akshay Bahdurkar
 * Author URI: https://procohat.com
 */


 if(!defined('ABSPATH')){
     header("Location: /custome/wordpress/");
     die();
 }


 function my_plugin_activation(){
     //for communicate db variable $wpdb se connection miljayega database ke sath and %table_prefix for name the table
     global $wpdb,$table_prefix;  
     //asign a table name
     $wp_emp = $table_prefix.'emp';
     //Query for create a new table wp_emp in db
     $q = "CREATE TABLE IF NOT EXISTS `$wp_emp` ( `ID` INT NOT NULL AUTO_INCREMENT ,
      `name` VARCHAR(50) NOT NULL ,`email` VARCHAR(100) NOT NULL , `status` BOOLEAN NOT NULL ,
       PRIMARY KEY (`ID`)) ENGINE = InnoDB;";
      
    $wpdb->query($q);  //for query exicution in wordpress 

    //insert data in db it takes two argument table name and array
    $data = array(
        'name' => 'Akshay',
        'email' => 'baakshay2612@gamai.com',
        'status' => 1
    );
    
    $wpdb->insert($wp_emp,$data);

    
     
 }
 register_activation_hook(__FILE__, 'my_plugin_activation');

 function my_plugin_deactivation(){
    global $wpdb,$table_prefix; 
    $wp_emp = $table_prefix.'emp';
    
    $q = "TRUNCATE `$wp_emp`";
    $wpdb->query($q);
}
register_deactivation_hook(__FILE__, 'my_plugin_deactivation');

//shortcode create
// function my_sc_fun(){
//     return 'Function call';
// }
// add_shortcode('my-sc','my_sc_fun');